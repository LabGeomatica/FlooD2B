from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterRasterLayer
from qgis.core import QgsProcessingParameterBoolean
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProcessingParameterVectorLayer
from qgis.core import QgsProcessingParameterFeatureSink
import processing


class FlooD2B(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer('raster__type_1_flood_map', 'Raster - Type 1 flood map', optional=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterRasterLayer('raster__type_2_flood_map', 'Raster - Type 2 flood map', optional=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterBoolean('use_type_1_flood_map', 'Use type 1 flood map', defaultValue=False))
        self.addParameter(QgsProcessingParameterBoolean('use_type_2_flood_map', 'Use type 2 flood map', defaultValue=False))
        self.addParameter(QgsProcessingParameterVectorLayer('vector_layer__buildings', 'Vector layer - Buildings', defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Taxonomy', 'Taxonomy', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('MaximumEconomicDamagePerBuildings', 'Maximum economic damage per buildings', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue='TEMPORARY_OUTPUT'))
        self.addParameter(QgsProcessingParameterFeatureSink('BuildingLayerPercentageDamageMethodA', 'Building layer - Percentage damage - METHOD A', optional=True, type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue='TEMPORARY_OUTPUT'))
        self.addParameter(QgsProcessingParameterFeatureSink('BuildingLayerEconomicDamageMethodA', 'Building layer - Economic Damage - METHOD A', optional=True, type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue='TEMPORARY_OUTPUT'))
        self.addParameter(QgsProcessingParameterFeatureSink('BuildingLayerPercentageDamageMethodB', 'Building layer - Percentage damage - METHOD B', optional=True, type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('BuildingLayerEconomicDamageMethodB', 'Building layer - Economic Damage - METHOD B', optional=True, type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue='TEMPORARY_OUTPUT'))

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(20, model_feedback)
        results = {}
        outputs = {}

        # Branch condizionale
        alg_params = {
        }
        outputs['BranchCondizionale'] = processing.run('native:condition', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Buffer - METHOD B
        alg_params = {
            'DISSOLVE': False,
            'DISTANCE': 2,
            'END_CAP_STYLE': 2,  # Quadrato
            'INPUT': parameters['vector_layer__buildings'],
            'JOIN_STYLE': 1,  # Seghettato
            'MITER_LIMIT': 2,
            'SEGMENTS': 5,
            'SEPARATE_DISJOINT': False,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BufferMethodB'] = processing.run('native:buffer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Geospatial data should refer to a cartographic reference system
        alg_params = {
            'INPUT': parameters['vector_layer__buildings'],
            'OPERATION': '',
            'TARGET_CRS': 'ProjectCrs',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['GeospatialDataShouldReferToACartographicReferenceSystem'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Fix geometries
        alg_params = {
            'INPUT': outputs['GeospatialDataShouldReferToACartographicReferenceSystem']['OUTPUT'],
            'METHOD': 1,  # Struttura
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FixGeometries'] = processing.run('native:fixgeometries', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Calculate area values of each building
        alg_params = {
            'FIELD_LENGTH': 20,
            'FIELD_NAME': 'Area',
            'FIELD_PRECISION': 3,
            'FIELD_TYPE': 0,  # Decimale (doppia precisione)
            'FORMULA': '$area',
            'INPUT': outputs['FixGeometries']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['CalculateAreaValuesOfEachBuilding'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Centroids
        alg_params = {
            'ALL_PARTS': False,
            'INPUT': outputs['CalculateAreaValuesOfEachBuilding']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Centroids'] = processing.run('native:centroids', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # Taxonomy
        alg_params = {
            'FIELD_LENGTH': 4,
            'FIELD_NAME': 'Building_typology',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # Intero (32 bit)
            'FORMULA': 'CASE \r\nWHEN "def_cat_us" = \'Residenziale-Abitativa\' THEN 1\r\nWHEN "def_cat_us" = \'Residenziale\' THEN 1\r\n\r\nWHEN "def_cat_us" = \'Amministrativo\' THEN 2\r\nWHEN "def_cat_us" = \'Amministrativo-municipio\' THEN 2\r\nWHEN "def_cat_us" = \'Amministrativo-sede provincia\' THEN 2\r\nWHEN "def_cat_us" = \'Amministrativo-sede regione\' THEN 2\r\nWHEN "def_cat_us" = \'Amministrativo-sede ambasciata\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico- ASL - sede generica\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico-ASL - sede di servizio socio assistenziale\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico-ASL - sede di ospedale\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico-sede di clinica\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico-sede di poste-telegrafi\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico-sede di scuola, università, laboratorio di ricerca\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico-sede di tribunale\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico-sede di polizia\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico-sede di vigili del fuoco\' THEN 2\r\nWHEN "def_cat_us" = \'Servizio pubblico-casello forestale\' THEN 2\r\nWHEN "def_cat_us" = \'Militare\' THEN 2\r\nWHEN "def_cat_us" = \'Militare-Caserma\' THEN 2\r\nWHEN "def_cat_us" = \'Militare-Prigione\' THEN 2\r\nWHEN "def_cat_us" = \'Luogo di culto\' THEN 2\r\nWHEN "def_cat_us" = \'Commerciale\' THEN 2\r\nWHEN "def_cat_us" = \'Commerciale-sede di banca\' THEN 2\r\nWHEN "def_cat_us" = \'Commerciale-sede di centro commerciale\' THEN 2\r\nWHEN "def_cat_us" = \'Commerciale-mercato\' THEN 2\r\nWHEN "def_cat_us" = \'Commerciale-sede di supermercato, ipermercato\' THEN 2\r\nWHEN "def_cat_us" = \'Commerciale-sede di albergo, locanda\' THEN 2\r\nWHEN "def_cat_us" = \'Commerciale-ostello della gioventù\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-sede di attività culturali\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-sede di attività culturali-biblioteca\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-sede di attività culturali-cinema\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-sede di attività culturali-teatro, auditorium\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-sede di attività culturali-museo\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-sede di attività culturali-pinacoteca\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-sede di attività sportive\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-sede di attività sportive-piscina coperta\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-sede di attività sportive-palestra\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-sede di attività sportive-palaghiaccio\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-altre attività\' THEN 2\r\nWHEN "def_cat_us" = \'Ricreativo-altre attività-campeggio\' THEN 2\r\n\r\nWHEN "def_cat_us" = \'Industriale\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-stabilimento industriale\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-impianto di produzione energia\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-impianto di produzione energia-centrale elettrica\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-impianto di produzione energia-centrale termoelettrica\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-impianto di produzione energia-centrale idroelettrica\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-impianto di produzione energia-centrale nucleare\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-impianto di produzione energia-stazione/sottostazione elettrica\' THEN 3\r\nWHEN  "def_cat_us" = \'Industriale-impianto di produzione energia-stazione di trasformazione\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-impianto di produzione energia-centrale eolica\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-impianto tecnologico\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-depuratore\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-inceneritore\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-stazione di telecomunicazioni\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-edificio di teleriscaldamento\' THEN 3\r\nWHEN "def_cat_us" = \'Industriale-edificio di area ecologica\' THEN 3\r\nWHEN "def_cat_us" = \'Agricolturale\' THEN 3\r\nWHEN "def_cat_us" = \'Agricolturale-fattoria\' THEN 3\r\nWHEN "def_cat_us" = \'Agricolturale-stalla\' THEN 3\r\nWHEN "def_cat_us" = \'Agricolturale-fienile\' THEN 3\r\n\r\nWHEN "def_cat_us" = \'Servizi di trasporto\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto aereo\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto aereo - Aerostazione\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto aereo - Stazione eliporto\'THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto stradale\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto stradale - Stazione autolinee\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto stradale-parcheggio multipiano o coperto\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto stradale-casello autostradale\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto stradale-stazione di rifornimento carburante autostradale\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto stradale-stazione di rifornimento carburante stradale\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto ferroviario\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto ferroviario- stazione passeggeri ferrovia\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto ferroviario-deposito ferroviario per vagoni, rimessa locomotive\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto ferroviario-casello ferroviario\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto ferroviario-fermata ferroviaria\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto ferroviario-scalo merci\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto-altri impianti\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto-altri impianti-stazione marittima\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto-altri impianti-stazione metropolitana\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto-altri impianti-stazione funivia\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto-altri impianti-stazione cabinovia\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto-altri impianti-stazione seggiovia\'THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto-altri impianti-stazione ski-lift\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto-altri impianti-stazione funicolare\' THEN 4\r\nWHEN "def_cat_us" = \'Servizi di trasporto-altri impianti-edificio marittimo\'THEN 4\r\n \r\nELSE 0\r\n\r\nEND ',
            'INPUT': outputs['Centroids']['OUTPUT'],
            'OUTPUT': parameters['Taxonomy']
        }
        outputs['Taxonomy'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Taxonomy'] = outputs['Taxonomy']['OUTPUT']

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # Taxonomy associated to buildings buffered
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELD': 'id',
            'FIELDS_TO_COPY': ['Building_typology'],
            'FIELD_2': 'id',
            'INPUT': outputs['BufferMethodB']['OUTPUT'],
            'INPUT_2': outputs['Taxonomy']['OUTPUT'],
            'METHOD': 1,  # Prendi solamente gli attributi del primo elemento corrispondente (uno-a-uno)
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['TaxonomyAssociatedToBuildingsBuffered'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # Maximum economic damage per buildings
        alg_params = {
            'FIELD_LENGTH': 20,
            'FIELD_NAME': 'Max_ec_dam',
            'FIELD_PRECISION': 2,
            'FIELD_TYPE': 0,  # Decimale (doppia precisione)
            'FORMULA': 'if( "Building_typology" = 1, ("Area"*739) ,if( "Building_typology" = 2, ("Area"*1028) ,if( "Building_typology" = 3, ("Area"*838) ,if( "Building_typology" = 4, ("Area"*625),0)))) ',
            'INPUT': outputs['Taxonomy']['OUTPUT'],
            'OUTPUT': parameters['MaximumEconomicDamagePerBuildings']
        }
        outputs['MaximumEconomicDamagePerBuildings'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['MaximumEconomicDamagePerBuildings'] = outputs['MaximumEconomicDamagePerBuildings']['OUTPUT']
        

                
        if parameters['raster__type_1_flood_map'] and parameters['use_type_1_flood_map']:
            
            feedback.setCurrentStep(15)
            if feedback.isCanceled():
                return {}
                
            # Flood depth associated to each buildings - METHOD A
            alg_params = {
                'COLUMN_PREFIX': 'Flood_depth',
                'INPUT': outputs['MaximumEconomicDamagePerBuildings']['OUTPUT'],
                'RASTERCOPY': parameters['raster__type_1_flood_map'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['FloodDepthAssociatedToEachBuildingsMethodA'] = processing.run('native:rastersampling', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(16)
            if feedback.isCanceled():
                return {}

        
            # Percentage of damage for each buildings - METHOD A
            alg_params = {
                'FIELD_LENGTH': 20,
                'FIELD_NAME': 'Perc_damage',
                'FIELD_PRECISION': 2,
                'FIELD_TYPE': 0,  # Decimale (doppia precisione)
                'FORMULA': 'if( "Building_typology" = 1, ((0.0006* ("Flood_depth1")^5)+(-0.0103* ("Flood_depth1")^4)+( 0.0722*("Flood_depth1")^3) +(-0.2528* ("Flood_depth1")^2)+(0.5873* ("Flood_depth1"))+ 0.0031) ,if( "Building_typology" = 2, ((-0.0004* ("Flood_depth1")^5)+(0.0054* ("Flood_depth1")^4)+(-0.0247*("Flood_depth1")^3) +(0.0184* ("Flood_depth1")^2)+(0.3051* ("Flood_depth1"))- 0.0013) ,if( "Building_typology" = 3, ((-0.0007* ("Flood_depth1")^5)+(0.0097* ("Flood_depth1")^4)+(-0.0431*("Flood_depth1")^3) +(0.0537* ("Flood_depth1")^2)+(0.255* ("Flood_depth1"))+ 0.0033) ,if( "Building_typology" = 4, ((-0.0007* ("Flood_depth1")^6)+(0.0125* ("Flood_depth1")^5)+(-0.0833*("Flood_depth1")^4) +(0.265* ("Flood_depth1")^3)+(-0.4939* ("Flood_depth1")^2)+(0.8364* ("Flood_depth1"))-0.0012),0))))',
                'INPUT': outputs['FloodDepthAssociatedToEachBuildingsMethodA']['OUTPUT'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['PercentageOfDamageForEachBuildingsMethodA'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)



            feedback.setCurrentStep(17)
            if feedback.isCanceled():
                return {}

            # Building layer - Percentage damage - METHOD A
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'id',
                'FIELDS_TO_COPY': ['Perc_damage'],
                'FIELD_2': 'id',
                'INPUT': parameters['vector_layer__buildings'],
                'INPUT_2': outputs['PercentageOfDamageForEachBuildingsMethodA']['OUTPUT'],
                'METHOD': 1,  # Prendi solamente gli attributi del primo elemento corrispondente (uno-a-uno)
                'PREFIX': '',
                'OUTPUT': parameters['BuildingLayerPercentageDamageMethodA']
            }
            outputs['BuildingLayerPercentageDamageMethodA'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['BuildingLayerPercentageDamageMethodA'] = outputs['BuildingLayerPercentageDamageMethodA']['OUTPUT']

            feedback.setCurrentStep(18)
            if feedback.isCanceled():
                return {}

            # Join attribute table for the calculation of the economic damage - METHOD A
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'id',
                'FIELDS_TO_COPY': ['Perc_damage'],
                'FIELD_2': 'id',
                'INPUT': outputs['PercentageOfDamageForEachBuildingsMethodA']['OUTPUT'],
                'INPUT_2': outputs['BuildingLayerPercentageDamageMethodA']['OUTPUT'],
                'METHOD': 1,  # Prendi solamente gli attributi del primo elemento corrispondente (uno-a-uno)
                'PREFIX': '',
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['JoinAttributeTableForTheCalculationOfTheEconomicDamageMethodA'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(19)
            if feedback.isCanceled():
                return {}

            # Economic Damage calculation - METHOD A
            alg_params = {
                'FIELD_LENGTH': 20,
                'FIELD_NAME': 'Econ_damage',
                'FIELD_PRECISION': 2,
                'FIELD_TYPE': 0,  # Decimale (doppia precisione)
                'FORMULA': '("Max_ec_dam")*("Perc_damage")',
                'INPUT': outputs['JoinAttributeTableForTheCalculationOfTheEconomicDamageMethodA']['OUTPUT'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['EconomicDamageCalculationMethodA'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(20)
            if feedback.isCanceled():
                return {}

            # Building layer - Economic Damage - METHOD A
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'id',
                'FIELDS_TO_COPY': ['Econ_damage'],
                'FIELD_2': 'id',
                'INPUT': parameters['vector_layer__buildings'],
                'INPUT_2': outputs['EconomicDamageCalculationMethodA']['OUTPUT'],
                'METHOD': 1,  # Prendi solamente gli attributi del primo elemento corrispondente (uno-a-uno)
                'PREFIX': '',
                'OUTPUT': parameters['BuildingLayerEconomicDamageMethodA']
            }
            outputs['BuildingLayerEconomicDamageMethodA'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['BuildingLayerEconomicDamageMethodA'] = outputs['BuildingLayerEconomicDamageMethodA']['OUTPUT']
            
            
        if parameters['raster__type_2_flood_map'] and parameters['use_type_2_flood_map']:

            feedback.setCurrentStep(9)
            if feedback.isCanceled():
                return {}

            # Flood depth calculation: mean statistic of the depth values contained in pixels' raster map - METHOD B
            alg_params = {
                'COLUMN_PREFIX': 'Flood_depth_',
                'INPUT': outputs['TaxonomyAssociatedToBuildingsBuffered']['OUTPUT'],
                'INPUT_RASTER': parameters['raster__type_2_flood_map'],
                'RASTER_BAND': 1,
                'STATISTICS': [2],  # Media
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['FloodDepthCalculationMeanStatisticOfTheDepthValuesContainedInPixelsRasterMapMethodB'] = processing.run('native:zonalstatisticsfb', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(10)
            if feedback.isCanceled():
                return {}

            # Percentage of damage for each buildings - METHOD B
            alg_params = {
                'FIELD_LENGTH': 20,
                'FIELD_NAME': 'Perc_damage',
                'FIELD_PRECISION': 2,
                'FIELD_TYPE': 0,  # Decimale (doppia precisione)
                'FORMULA': 'if( "Building_typology" = 1, ((0.0006* ("Flood_depth_mean")^5)+(-0.0103* ("Flood_depth_mean")^4)+( 0.0722*("Flood_depth_mean")^3) +(-0.2528* ("Flood_depth_mean")^2)+(0.5873* ("Flood_depth_mean"))+ 0.0031) ,if( "Building_typology" = 2, ((-0.0004* ("Flood_depth_mean")^5)+(0.0054* ("Flood_depth_mean")^4)+(-0.0247*("Flood_depth_mean")^3) +(0.0184* ("Flood_depth_mean")^2)+(0.3051* ("Flood_depth_mean"))- 0.0013) ,if( "Building_typology" = 3, ((-0.0007* ("Flood_depth_mean")^5)+(0.0097* ("Flood_depth_mean")^4)+(-0.0431*("Flood_depth_mean")^3) +(0.0537* ("Flood_depth_mean")^2)+(0.255* ("Flood_depth_mean"))+ 0.0033) ,if( "Building_typology" = 4, ((-0.0007* ("Flood_depth_mean")^6)+(0.0125* ("Flood_depth_mean")^5)+(-0.0833*("Flood_depth_mean")^4) +(0.265* ("Flood_depth_mean")^3)+(-0.4939* ("Flood_depth_mean")^2)+(0.8364* ("Flood_depth_mean"))-0.0012),0))))',
                'INPUT': outputs['FloodDepthCalculationMeanStatisticOfTheDepthValuesContainedInPixelsRasterMapMethodB']['OUTPUT'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['PercentageOfDamageForEachBuildingsMethodB'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            
            feedback.setCurrentStep(11)
            if feedback.isCanceled():
                return {}
                    
            # Building layer - Percentage damage - METHOD B
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'id',
                'FIELDS_TO_COPY': ['Perc_damage'],
                'FIELD_2': 'id',
                'INPUT': parameters['vector_layer__buildings'],
                'INPUT_2': outputs['PercentageOfDamageForEachBuildingsMethodB']['OUTPUT'],
                'METHOD': 1,  # Prendi solamente gli attributi del primo elemento corrispondente (uno-a-uno)
                'PREFIX': '',
                'OUTPUT': parameters['BuildingLayerPercentageDamageMethodB']
            }
            outputs['BuildingLayerPercentageDamageMethodB'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['BuildingLayerPercentageDamageMethodB'] = outputs['BuildingLayerPercentageDamageMethodB']['OUTPUT']

            feedback.setCurrentStep(12)
            if feedback.isCanceled():
                return {}

            # Join attribute table for the calculation of the economic damage - METHOD B
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'id',
                'FIELDS_TO_COPY': ['Perc_damage'],
                'FIELD_2': 'id',
                'INPUT': outputs['MaximumEconomicDamagePerBuildings']['OUTPUT'],
                'INPUT_2': outputs['BuildingLayerPercentageDamageMethodB']['OUTPUT'],
                'METHOD': 1,  # Prendi solamente gli attributi del primo elemento corrispondente (uno-a-uno)
                'PREFIX': '',
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['JoinAttributeTableForTheCalculationOfTheEconomicDamageMethodB'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            feedback.setCurrentStep(13)
            if feedback.isCanceled():
                return {}

            # Economic Damage calculation - METHOD B
            alg_params = {
                'FIELD_LENGTH': 20,
                'FIELD_NAME': 'Econ_damage',
                'FIELD_PRECISION': 2,
                'FIELD_TYPE': 0,  # Decimale (doppia precisione)
                'FORMULA': '("Max_ec_dam")*("Perc_damage")',
                'INPUT': outputs['JoinAttributeTableForTheCalculationOfTheEconomicDamageMethodB']['OUTPUT'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['EconomicDamageCalculationMethodB'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                
            feedback.setCurrentStep(14)
            if feedback.isCanceled():
                return {}

            # Building layer - Economic Damage - METHOD B
            alg_params = {
                'DISCARD_NONMATCHING': False,
                'FIELD': 'id',
                'FIELDS_TO_COPY': ['Econ_damage'],
                'FIELD_2': 'id',
                'INPUT': parameters['vector_layer__buildings'],
                'INPUT_2': outputs['EconomicDamageCalculationMethodB']['OUTPUT'],
                'METHOD': 1,  # Prendi solamente gli attributi del primo elemento corrispondente (uno-a-uno)
                'PREFIX': '',
                'OUTPUT': parameters['BuildingLayerEconomicDamageMethodB']
            }
            outputs['BuildingLayerEconomicDamageMethodB'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['BuildingLayerEconomicDamageMethodB'] = outputs['BuildingLayerEconomicDamageMethodB']['OUTPUT']
        return results

    def name(self):
        return 'FlooD2B'

    def displayName(self):
        return 'FlooD2B'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)
    
    def shortHelpString(self):
        return self.tr("The plugin automatically maps the taxonomy of built-up area cartography onto major flood vulnerability curve databases for damage estimation, extracts hydraulic properties (e.g., water depth) from flood hazard maps, and associates them to each exposed building. It offers a choice between 'filling' flood maps (type 1) or maps showing water flow around buildings (type 2), using specific methods: method (A) for type 1 and method (B) for type 2. The plugin assesses the resulting physical damage, quantifying both percentage and economic loss, at the building scale.\\n\\nThe plugin bases its scripts on methodologies applied to align the taxonomies of the official cartography of the built environment of the Liguria Region (available on the Geoportal of Liguria Region, 2022) with the vulnerability curves for Europe adapted by the Joint Research Centre of the European Commission (JRC). Users can modify the script to adapt the plugin to match any pair of exposed asset and vulnerability curve taxonomies at the building scale, accommodating different hazard types.")

    def group(self):
        return ''

    def groupId(self):
        return ''

    def createInstance(self):
        return FlooD2B()
